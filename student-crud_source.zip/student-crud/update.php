<?php
require 'config/db.php';
ini_set('display_errors',1);
error_reporting(E_ALL);

function uploadImage($file){
    if(!isset($file) || $file['error']===4) return null;
    $allowed = ['image/jpeg','image/png','image/gif'];
    if(!in_array($file['type'],$allowed)) return null;
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $name = time().'_'.bin2hex(random_bytes(6)).'.'.$ext;
    $dest = __DIR__ . '/uploads/' . $name;
    if(!move_uploaded_file($file['tmp_name'], $dest)) return null;
    return $name;
}

$id = (int)($_POST['id'] ?? 0);
if(!$id){ header('Location: index.php'); exit; }

$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$contact = trim($_POST['contact'] ?? '');
$course = trim($_POST['course'] ?? '');

$errors = [];
if(!preg_match('/^[0-9]+$/', $contact)) $errors[] = 'Contact must be numeric';

// Check email uniqueness
$stmt = $pdo->prepare("SELECT id FROM students WHERE email=:email AND id!=:id");
$stmt->execute([':email'=>$email, ':id'=>$id]);
if($stmt->fetch()) $errors[] = 'Email already exists';

if($errors){
    echo implode('<br>',$errors);
    echo '<br><a href="edit.php?id='.$id.'">Back</a>';
    exit;
}

$stmt = $pdo->prepare("SELECT image FROM students WHERE id=:id");
$stmt->execute([':id'=>$id]);
$old = $stmt->fetch();
$imageName = uploadImage($_FILES['image'] ?? null);
if(!$imageName && $old) $imageName = $old['image'];

$stmt = $pdo->prepare("UPDATE students SET name=:name,email=:email,contact=:contact,course=:course,image=:image WHERE id=:id");
$stmt->execute([
    ':name'=>$name,
    ':email'=>$email,
    ':contact'=>$contact,
    ':course'=>$course,
    ':image'=>$imageName,
    ':id'=>$id
]);

header('Location: index.php');
exit;
