<?php
require 'config/db.php';
ini_set('display_errors', 1);
error_reporting(E_ALL);

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if(!$id){ header('Location: index.php'); exit; }

// get image
$stmt = $pdo->prepare("SELECT image FROM students WHERE id=:id");
$stmt->execute([':id'=>$id]);
$row = $stmt->fetch();
if($row && $row['image'] && file_exists('uploads/'.$row['image'])){
    @unlink('uploads/'.$row['image']);
}

// delete
$stmt = $pdo->prepare("DELETE FROM students WHERE id=:id");
$stmt->execute([':id'=>$id]);

header('Location: index.php');
exit;
