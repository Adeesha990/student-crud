<?php
require 'config/db.php';
ini_set('display_errors', 1);
error_reporting(E_ALL);

function uploadImage($file){
    if(!isset($file) || $file['error']===4) return null;
    $allowed = ['image/jpeg','image/png','image/gif'];
    if(!in_array($file['type'],$allowed)) return null;
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $name = time().'_'.bin2hex(random_bytes(6)).'.'.$ext;
    $dest = __DIR__ . '/uploads/' . $name;
    if(!move_uploaded_file($file['tmp_name'], $dest)) return null;
    return $name;
}

$student_id = trim($_POST['student_id'] ?? '');
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$contact = trim($_POST['contact'] ?? '');
$course = trim($_POST['course'] ?? '');

$errors = [];
if(!preg_match('/^[0-9]+$/', $contact)) $errors[] = 'Contact must be numeric';

$stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE student_id=:sid OR email=:em");
$stmt->execute([':sid'=>$student_id, ':em'=>$email]);
if($stmt->fetchColumn() > 0) $errors[] = 'Student ID or Email already exists';

if($errors){
    echo implode('<br>', $errors);
    echo '<br><a href="create.php">Back</a>';
    exit;
}

$imageName = uploadImage($_FILES['image'] ?? null);

$stmt = $pdo->prepare("INSERT INTO students (student_id,name,email,contact,course,image) VALUES (:sid,:name,:email,:contact,:course,:image)");
$stmt->execute([
    ':sid'=>$student_id,
    ':name'=>$name,
    ':email'=>$email,
    ':contact'=>$contact,
    ':course'=>$course,
    ':image'=>$imageName
]);

header('Location: index.php');
exit;
