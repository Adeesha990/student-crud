<?php
require 'config/db.php';
ini_set('display_errors',1);
error_reporting(E_ALL);

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if(!$id){ header('Location: index.php'); exit; }

$stmt = $pdo->prepare("SELECT * FROM students WHERE id=:id");
$stmt->execute([':id'=>$id]);
$student = $stmt->fetch();
if(!$student){ header('Location: index.php'); exit; }
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Student</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2>Student Details</h2>
    <div class="card p-3" style="width: 400px;">
        <?php if($student['image'] && file_exists('uploads/'.$student['image'])): ?>
            <img src="uploads/<?= $student['image'] ?>" width="150" class="mb-3">
        <?php endif; ?>
        <p><strong>Student ID:</strong> <?= htmlspecialchars($student['student_id']) ?></p>
        <p><strong>Name:</strong> <?= htmlspecialchars($student['name']) ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($student['email']) ?></p>
        <p><strong>Contact:</strong> <?= htmlspecialchars($student['contact']) ?></p>
        <p><strong>Course:</strong> <?= htmlspecialchars($student['course']) ?></p>
        <p><strong>Created At:</strong> <?= $student['created_at'] ?></p>
        <?php if(isset($student['updated_at'])): ?>
            <p><strong>Updated At:</strong> <?= $student['updated_at'] ?></p>
        <?php endif; ?>
        <a href="index.php" class="btn btn-secondary mt-2">Back</a>
    </div>
</div>
</body>
</html>
