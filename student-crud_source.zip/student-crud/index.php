<?php
require 'config/db.php';
ini_set('display_errors', 1);
error_reporting(E_ALL);

$limit = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

$search = trim($_GET['search'] ?? '');
$where = '';
$params = [];
if($search){
    $where = "WHERE student_id LIKE :search OR name LIKE :search OR email LIKE :search OR contact LIKE :search OR course LIKE :search";
    $params[':search'] = "%$search%";
}

$totalStmt = $pdo->prepare("SELECT COUNT(*) FROM students $where");
$totalStmt->execute($params);
$total = $totalStmt->fetchColumn();
$totalPages = ceil($total / $limit);

$stmt = $pdo->prepare("SELECT * FROM students $where ORDER BY id DESC LIMIT :offset, :limit");
foreach($params as $k => $v) $stmt->bindValue($k, $v);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->execute();
$students = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2>Student List</h2>
    <a href="create.php" class="btn btn-primary mb-2">Add Student</a>
    <form method="get" class="mb-3">
        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search..." class="form-control w-25 d-inline">
        <button class="btn btn-secondary">Search</button>
    </form>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Student ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Course</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php if($students): ?>
            <?php foreach($students as $s): ?>
                <tr>
                    <td><?= $s['id'] ?></td>
                    <td><?= htmlspecialchars($s['student_id']) ?></td>
                    <td><?= htmlspecialchars($s['name']) ?></td>
                    <td><?= htmlspecialchars($s['email']) ?></td>
                    <td><?= htmlspecialchars($s['contact']) ?></td>
                    <td><?= htmlspecialchars($s['course']) ?></td>
                    <td>
                        <?php if($s['image'] && file_exists('uploads/'.$s['image'])): ?>
                            <img src="uploads/<?= $s['image'] ?>" width="50">
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="view.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-info">View</a>
                        <a href="edit.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                        <a href="delete.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="8" class="text-center">No students found.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>

    <nav>
        <ul class="pagination">
            <?php for($i=1;$i<=$totalPages;$i++): ?>
                <li class="page-item <?= $i==$page ? 'active':'' ?>">
                    <a class="page-link" href="?page=<?= $i ?>&search=<?= urlencode($search) ?>"><?= $i ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>
</div>
</body>
</html>
