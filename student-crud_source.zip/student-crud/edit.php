<?php
require 'config/db.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if(!$id){
    echo "Invalid ID";
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM students WHERE id = :id");
$stmt->execute([':id'=>$id]);
$student = $stmt->fetch();

if(!$student){
    echo "Student not found!";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Student</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container py-4">

<h2>Edit Student</h2>

<form action="update.php" method="POST" enctype="multipart/form-data">

    <input type="hidden" name="id" value="<?= $student['id'] ?>">

    <div class="mb-3">
        <label>Student ID</label>
        <input type="text" class="form-control" name="student_id" value="<?= $student['student_id'] ?>" readonly>
    </div>

    <div class="mb-3">
        <label>Full Name</label>
        <input type="text" class="form-control" name="name" value="<?= $student['name'] ?>" required>
    </div>

    <div class="mb-3">
        <label>Email</label>
        <input type="email" class="form-control" name="email" value="<?= $student['email'] ?>" required>
    </div>

    <div class="mb-3">
        <label>Contact</label>
        <input type="text" class="form-control" name="contact" value="<?= $student['contact'] ?>" required>
    </div>

    <div class="mb-3">
        <label>Course</label>
        <input type="text" class="form-control" name="course" value="<?= $student['course'] ?>" required>
    </div>

    <div class="mb-3">
        <label>Current Image:</label><br>
        <?php if($student['image']) { ?>
            <img src="uploads/<?= $student['image'] ?>" width="120" class="border">
        <?php } else { ?>
            <p>No Image</p>
        <?php } ?>
    </div>

    <div class="mb-3">
        <label>Upload New Image (optional)</label>
        <input type="file" class="form-control" name="image">
    </div>

    <button type="submit" class="btn btn-primary">Update</button>
    <a href="index.php" class="btn btn-secondary">Cancel</a>

</form>

</body>
</html>
